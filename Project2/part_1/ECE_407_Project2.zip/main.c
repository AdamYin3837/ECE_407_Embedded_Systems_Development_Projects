#include <stdio.h>
#include "pico/stdlib.h"
#include "hardware/pwm.h"
#include "hardware/adc.h"
#include "hardware/pio.h"
#include "hardware/clocks.h"

#define POTENTIOMETER_PIN 26
#define LED_DIN_PIN 28
#define NUM_LEDS 12

// Inline Pre-compiled PIO Program
static const uint16_t ws2812_program_instructions[] = {
    0x6221, //  0: out    x, 1            side 0 [2] 
    0x1123, //  1: jmp    !x, 3           side 1 [1] 
    0x1400, //  2: jmp    0               side 1 [4] 
    0xa442, //  3: nop                    side 0 [4] 
};

static const struct pio_program ws2812_program = {
    .instructions = ws2812_program_instructions,
    .length = 4,
    .origin = -1,
};

static inline pio_sm_config ws2812_program_get_default_config(uint offset) {
    pio_sm_config c = pio_get_default_sm_config();
    sm_config_set_wrap(&c, offset + 0, offset + 3);
    sm_config_set_sideset(&c, 1, false, false);
    return c;
}

static inline void ws2812_program_init(PIO pio, uint sm, uint offset, uint pin, float freq, bool is_rgbw) {
    pio_gpio_init(pio, pin);
    pio_sm_set_consecutive_pindirs(pio, sm, pin, 1, true);
    pio_sm_config c = ws2812_program_get_default_config(offset);
    sm_config_set_sideset_pins(&c, pin);
    sm_config_set_out_shift(&c, false, true, is_rgbw ? 32 : 24);
    sm_config_set_fifo_join(&c, PIO_FIFO_JOIN_TX);
    
    int cycles_per_bit = 10; 
    float div = clock_get_hz(clk_sys) / (freq * cycles_per_bit);
    sm_config_set_clkdiv(&c, div);
    
    pio_sm_init(pio, sm, offset, &c);
    pio_sm_set_enabled(pio, sm, true);
}
// ============================================================================

// Helper to send RGB data to PIO
static inline void put_pixel(uint32_t pixel_grb) {
    pio_sm_put_blocking(pio0, 0, pixel_grb << 8u);
}

// Helper to pack RGB into 32-bit (WS2812 expects GRB order)
static inline uint32_t urgb_u32(uint8_t r, uint8_t g, uint8_t b) {
    return ((uint32_t)(r) << 8) | ((uint32_t)(g) << 16) | (uint32_t)(b);
}

int main() {
    stdio_init_all();
    adc_init();

    // Setup PWM & ADC
    gpio_set_function(16, GPIO_FUNC_PWM);
    gpio_set_function(17, GPIO_FUNC_PWM);
    adc_gpio_init(POTENTIOMETER_PIN);
    adc_select_input(0);

    uint slice_num = pwm_gpio_to_slice_num(16);
    pwm_set_clkdiv(slice_num, 3.0f);
    pwm_set_wrap(slice_num, 4095);
    pwm_set_enabled(slice_num, true);

    // Setup PIO WS2812
    PIO pio = pio0;
    int sm = 0;
    uint offset = pio_add_program(pio, &ws2812_program);
    ws2812_program_init(pio, sm, offset, LED_DIN_PIN, 800000, false);

    while (1) {
        uint16_t result = adc_read();
        const int center = 2048;
        const int deadzone = 100;
        
        int duty_A = 0; 
        int duty_B = 0; 
        int speed_magnitude = 0; 
        bool is_forward = true;

        // Directional Logic
        if (result > (center + deadzone)) {
            speed_magnitude = result - (center + deadzone);
            duty_A = speed_magnitude * 4095 / (4095 - (center + deadzone));
            is_forward = true;
        } 
        else if (result < (center - deadzone)) {
            speed_magnitude = (center - deadzone) - result;
            duty_B = speed_magnitude * 4095 / (center - deadzone);
            is_forward = false;
        }

        // Apply Clamps
        if (duty_A > 4095) duty_A = 4095;
        if (duty_B > 4095) duty_B = 4095;

        // Apply PWM
        pwm_set_chan_level(slice_num, PWM_CHAN_A, duty_A);
        pwm_set_chan_level(slice_num, PWM_CHAN_B, duty_B);

        // Update RGB Ring Display
        int leds_to_light = (speed_magnitude * NUM_LEDS) / (2048 - deadzone);
        if (leds_to_light > NUM_LEDS) leds_to_light = NUM_LEDS;

        for (int i = 0; i < NUM_LEDS; i++) {
            if (i < leds_to_light) {
                if (is_forward) {
                    put_pixel(urgb_u32(255, 0, 0)); // Red for Forward
                } else {
                    put_pixel(urgb_u32(0, 0, 255)); // Blue for Reverse
                }
            } else {
                put_pixel(urgb_u32(0, 0, 0)); // Turn off unused LEDs
            }
        }
        sleep_ms(50);
    }
}